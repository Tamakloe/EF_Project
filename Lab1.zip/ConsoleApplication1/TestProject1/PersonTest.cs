﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApplication1;

namespace TestProject1
{
    [TestClass]
    public class PersonTest
    {
        Person p = new Person("Mary", 21);

        [TestMethod]
        public void TestMakeUpString()
        {
            String str = p.makeUpName();
            Assert.AreEqual("This is the persons name Mary", str);
        }
    }
}
