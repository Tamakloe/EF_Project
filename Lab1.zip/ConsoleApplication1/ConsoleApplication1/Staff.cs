﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class Staff : Person // staff inherits person class
    {
        private int officeNumber;

        // Getter & Setter Methods
        public int getOfficeNumber()
        {
            return officeNumber;
        }

        public void setOfficeNumber(int onum)
        {
            this.officeNumber = onum;
        }
    }
}
