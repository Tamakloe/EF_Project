﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class Person
    {
        private int age;
        private string name;

        public Person()
        {
            Console.WriteLine("This is the basic/default constructor");
            // a constructor is the method that gets called when a new object is created
        }

        public Person(String name, int age) // this forces the class to take these two arg's
        {
            this.age = age;
            this.name = name;
        }

        // Getter & Setter Methods
        public int getage()
        {
            return this.age;
        }

        public void setage(int oage)
        {
            this.age = oage;
        }


        public string getname()
        {
            return this.name;
        }

        public void setname(string oname)
        {
            this.name = oname;
        }


        public string toString()
        {
            return this.name + " is " + this.age;
       //     return "This persons name is " + this.name;
        }


        public String makeUpName()
        {
            String str = "This is the persons name " + name;
            return str;
        }



    }



}
