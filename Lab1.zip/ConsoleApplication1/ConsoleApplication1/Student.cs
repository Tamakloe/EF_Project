﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class Student : Person  // student inherits person class
    {
        private int idNumber;

        // Getter & Setter Methods
        public int getidNumber()
        {
            return idNumber;
        }

        public void setidNumber(int idnum)
        {
            this.idNumber = idnum;
        }
    }


}
