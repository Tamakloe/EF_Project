﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Person newperson1 = new Person();  // constructor
            Person newperson2 = new Person();
            
            newperson1.setage(12);
            newperson2.setage(34);

            Console.WriteLine(newperson1.toString());
            Console.WriteLine(newperson2.toString());

            Console.ReadLine();
            */

            String[] inputnameArray;
            inputnameArray = new String[3];


            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Enter a name");
                inputnameArray[i] = Console.ReadLine(); 
                Person p = new Person(inputnameArray[i], i + 10 * 2);  // this uses the new, not the default constructor


             //   p.setage(i + 10 * 2);
             //   p.setname(inputnameArray[i]);
                Console.WriteLine(p.toString());
            }
            
            Console.ReadLine();
        }
    }
}
